<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>reviewer</title>
</head>
<body>

<?php
session_start();
if(@$_SESSION["login"]!="yes"){
    echo "<h1>非法進入，請先登入。2秒後離開...</h1>";
    header("Refresh:2 url=index.php");
}elseif($_SESSION["login"]!="yes"||$_SESSION["type"]!="reviewer"){
    header("location:check.php");
}else{
    echo "<h1>歡迎~這裡是reviewer頁面</h1>";
    echo "你可以<a href='logout.php'>點此</a>登出!";
}
?>

<form method="post" action="showreview.php">

<h1>Reviewer您好，歡迎進入論文評論網頁</h1>
論文評審決定:
<input type="radio" name="review" value="Accept"checked>Accept
<input type="radio" name="review" value="Minor Revision">Minor Revision
<input type="radio" name="review" value="Major Revision">Major Revision
<input type="radio" name="review" value="Reject">Reject
</br>
論文評論評語:
<textarea name="comment" value="" rows="10" cols="100">
</textarea>
</br>
<input type="submit" value="提交">
</form>

<?php
include("include.inc");
?>
