<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>author</title>
</head>
<body>

<?php
session_start();
if(@$_SESSION["login"]!="yes"){
    echo "<h1>非法進入，請先登入。2秒後離開...</h1>";
    header("Refresh:2 url=index.php");
}elseif($_SESSION["login"]!="yes"||$_SESSION["type"]!="author"){
    header("location:check.php");
}else{
    echo "<h1>歡迎~這裡是author頁面</h1>";
    echo "你可以<a href='logout.php'>點此</a>登出!";
}
?>

<form method="post" action="showpaper.php">

<h1>Author您好，歡迎進入論文投稿網頁</h1>
論文標題:</br>
<input type="text" name="Title" value=""></br>
作者姓名:<input type="text" name="Name" value=""></br>
作者Email:<input type="email" name="Mail" value=""></br>
論文摘要:
<textarea name="summary" value="" rows="10" cols="100">

</textarea>
</br>
<input type="submit" value="提交">
</form>

<?php
include("include.inc");
?>