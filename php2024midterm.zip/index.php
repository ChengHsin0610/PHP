<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>首頁</title>
</head>
<body>
<h1>高大資管論文投稿系統</h1><br/>
    <?php
    session_start();
    if(@$_SESSION["login"]=="yes"){
        session_destroy();
        header("Location:login.php");
    }
    ?>
    <form method="post" action="check.php">
    請選擇您的角色:
    <select name="sIdentity">
    <option value="chair" selected>Chair
    <option value="reviewer">Reviewer
    <option value="author">Author
    </select>

    <br/>

    <?php
        if(isset($_COOKIE["name"])){
            echo "帳號:<input type='text' value='".$_COOKIE["name"]."'name='account'><br/>
            密碼:<input type='text' name='password'><br/>";
        }else{
            echo "帳號:<input type='text' name='account'><br/>
            密碼:<input type='text' name='password'><br/>";
        }
    ?>
    <input type="submit" value="提交">
    </from>
</body>
</html>