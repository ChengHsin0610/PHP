<?php
session_start();
if(isset($_POST["summary"])){
    echo addslashes(nl2br($_POST["summary"]));
}

echo "<h1>歡迎~這裡是showpaper頁面</h1>";
echo "你可以<a href='logout.php'>點此</a>登出!";
?>

