<?php
session_start();
if(isset($_POST["comment"])){
    echo addslashes(nl2br($_POST["comment"]));
}

echo "<h1>歡迎~這裡是showreview頁面</h1>";
echo "你可以<a href='logout.php'>點此</a>登出!";
?>
